#ifndef _CM3DRIVERPUBLICTYPES_H_
#define _CM3DRIVERPUBLICTYPES_H_

#include "DCSCDriverPublicConstants.h"

typedef unsigned char                   UInt8;
typedef signed char                     SInt8;
typedef unsigned short                  UInt16;
typedef signed short                    SInt16;

#if __LP64__
typedef unsigned int                    UInt32;
typedef signed int                      SInt32;
#else
	#if __MACOS__
typedef unsigned long                   UInt32;
typedef signed long                     SInt32;
	#else
		typedef unsigned int            UInt32;
		typedef signed int              SInt32;
	#endif
#endif
typedef UInt8                           Byte;

// STRUCTURE FOR REFLECTANCE DATA
typedef struct
{
	Byte	MeasMode;										// MODE_RAW etc.
	UInt16	Dark1_samp,Dark2_samp,Dark1_ref,Dark2_ref;
	UInt16	SamRaw[NUM_BANDS],RefRaw[NUM_BANDS];
	float	L, a, b;
	float	X, Y, Z;
} flt_structMeasData;

// A callback that allows the low level driver to pass measure/up/down
// button events up to the user application
// It is up to the higher layer to register a callback by calling
// SetApplicationCallback()
typedef void (FN_ButtonEvt)(int buttonID);
typedef FN_ButtonEvt *PFN_ButtonEvt;
typedef void (FN_ButtonEvtEx)(int buttonID, void *userData);
typedef FN_ButtonEvtEx *PFN_ButtonEvtEx;

// A type to store a password for the stand alone device
typedef char DCSC_Password[10];

//The device handle type used by the Ex functions
typedef void *DCSC_HANDLE;

#endif