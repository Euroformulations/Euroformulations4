#ifndef _INSTDRIVERPUBLICCONSTANTS_H_
#define _INSTDRIVERPUBLICCONSTANTS_H_

// Macro for creating error codes (based on winerror.h)
/*
Severity
0=Success
1=Informational
2=Warning
3=Error
*/
#ifndef MAKEERRCODE
#define MAKEERRCODE(Severity, Facility, Exception) \
   ((unsigned long) ( \
   /* Severity code    */  (Severity  << 30) |     \
   /* MS(0) or Cust(1) */  (1         << 29) |     \
   /* Reserved(0)      */  (0         << 28) |     \
   /* Facility code    */  (Facility  << 16) |     \
   /* Exception code   */  (Exception <<  0)))
#endif


//Internal error codes returned by the device ***********************************
//These error codes are returned internally by the device, not to tou!
//DO NOT check for them, instead check for the DCSC_ERR_ coes below.
#define DEV_DCSC_ERR_OK					0x00		// no error
#define DEV_DCSC_ERR_INVALID_PARM		0x01		// bad parameter send to function
#define DEV_DCSC_ERR_SMBUS_BUSY			0x10		// try to perform bus read/write with SI cleared
#define DEV_DCSC_ERR_SMBUS_NOACK		0x11		// no response from smbus peripheral
#define DEV_DCSC_ERR_SMBUS_READTIMO		0x12		// timeout during read operation
#define DEV_DCSC_ERR_SMBUS_BADSTATE		0x1f		// in ISR -- received bad state code (upper 6 bits of SMB0CN)
#define DEV_DCSC_ERR_MEAS_PARCHANPARM	0x40		// invalid parameter during attempt at channel measurement
#define DEV_DCSC_ERR_MEAS_PARSAMP		0x41		// unmatched samping rates during attempt at parallel channel measurements
#define DEV_DCSC_ERR_PROFILE_PARSE		0x50		// trouble parsing profile
#define DEV_DCSC_ERR_PROFILE_READ		0x51		// trouble getting profile from memory
#define DEV_DCSC_ERR_PROFILE_WRITE		0x52		// trouble getting profile from memory
#define DEV_DCSC_ERR_MEAS_AUTOTR_FAST	0x53		// A measurement after auto triggering did not match up the red LED raw counts
/* Bootloader Error Returns */
#define DEV_DCSC_ERR_UNSUP_CMD			0x70		// Unsupported command.
#define DEV_DCSC_ERR_PGM_FAILURE		0x71		// FLASH reports error during programming.
#define DEV_DCSC_ERR_BAD_SIGN			0x72		// Signature did not match data.
#define DEV_DCSC_ERR_LOCK_FAILURE		0x73		// FLASH memory lock/unlock command failed
/* end bootloader */

#define	ERR_DCSC_ERR_UNDEF_MEM_ADDR		0x80		// unrecognized memory address

#define DEV_DCSC_ERR_USB_READ			0x81		// USB read error
#define DEV_DCSC_ERR_USB_WRITE			0x82		// USB write error

#define DEV_DCSC_ERR_INTERNAL_SEM		0xf0		// Could not get semaphore
#define DEV_DCSC_ERR_UNDEF_ISR1			0xf1
#define DEV_DCSC_ERR_UNDEF_ISR2			0xf2
#define DEV_DCSC_ERR_UNDEF_ISR3			0xf3
#define DEV_DCSC_ERR_UNDEF_ISR4			0xf4
////#define DEV_DCSC_ERR_UNDEF_ISR5		0xf5
#define DEV_DCSC_ERR_UNDEF_ISR6			0xf6
////#define DEV_DCSC_ERR_UNDEF_ISR7		0xf7
////#define DEV_DCSC_ERR_UNDEF_ISR8		0xf8
#define DEV_DCSC_ERR_UNDEF_ISR9			0xf9
#define DEV_DCSC_ERR_UNDEF_ISR10		0xfa
#define DEV_DCSC_ERR_UNDEF_ISR11		0xfb
////#define DEV_DCSC_ERR_UNDEF_ISR12	0xfc
#define DEV_DCSC_ERR_UNDEF_ISR13		0xfd
////#define DEV_DCSC_ERR_UNDEF_ISR14	0xfe
#define DEV_DCSC_ERR_UNDEF_ISR15		0xff

#define DEV_DCSC_ERR_DEVICE_LOCKED		0xC0
#define DEV_DCSC_ERR_STORAGE_FULL		0xC1
#define DEV_DCSC_ERR_STORAGE_WRITE		0xC2
#define DEV_DCSC_ERR_STORAGE_READ		0xC3
#define DEV_DCSC_ERR_STORAGE_DELETE		0xC4
#define DEV_DCSC_ERR_FILE_NOT_FOUND		0xC5
#define DEV_DCSC_ERR_NOT_ENOUGH_DATA	0xC6
#define DEV_DCSC_ERR_INVALID_PASSWORD	0xC7
// END device error codes ***********************************

//DCSC Facility code
#define DCSC_ERRF	0

//Error codes returned by the driver
//In addition to these all OS error codes may also be returned
#define DCSC_ERR_SUCCESS						0
#define DCSC_ERR_UNEXPECTED_STATE			MAKEERRCODE(3, DCSC_ERRF, 1)
#define DCSC_ERR_UNEXPECTED_MEAS_DATA		MAKEERRCODE(3, DCSC_ERRF, 2)
#define DCSC_ERR_INVALID_PARAMETERS			MAKEERRCODE(3, DCSC_ERRF, 3)
#define DCSC_ERR_DEVICE_NOT_OPENED			MAKEERRCODE(3, DCSC_ERRF, 4)
#define DCSC_ERR_DEV_WRITE_TIME_OUT			MAKEERRCODE(3, DCSC_ERRF, 5)
#define DCSC_ERR_DEV_READ_TIME_OUT			MAKEERRCODE(3, DCSC_ERRF, 6)
#define DCSC_ERR_OUTPUT_MODE_NOT_AVAILABLE	MAKEERRCODE(3, DCSC_ERRF, 7)
#define DCSC_ERR_LOADING_DRIVER				MAKEERRCODE(3, DCSC_ERRF, 8)	//Mac only
#define DCSC_ERR_BAD_AUTHORIZATION			MAKEERRCODE(3, DCSC_ERRF, 9)	//DAG090418 invalid license code passed to Authorize
#define DCSC_ERR_UNKNOWN_USB_PRODUCT_ID		MAKEERRCODE(3, DCSC_ERRF,11)	//DAG090420 an unexpected USB Product ID was encountered

//DCSC Device Facility code
#define DCSC_DEV_ERRF	1

//Internal error codes returned by the device
//These are error codes returned internally by the device.
//#define DEV_DCSC_ERR_OK					MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_OK)					// 0x00			// no error
#define DCSC_ERR_INVALID_PARM			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_INVALID_PARM)		// 0x01			// bad parameter send to function
#define DCSC_ERR_SMBUS_BUSY				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_SMBUS_BUSY)			// 0x10			// try to perform bus read/write with SI cleared
#define DCSC_ERR_SMBUS_NOACK			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_SMBUS_NOACK)			// 0x11			// no response from smbus peripheral
#define DCSC_ERR_SMBUS_READTIMO			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_SMBUS_READTIMO)		// 0x12			// timeout during read operation
#define DCSC_ERR_SMBUS_BADSTATE			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_SMBUS_BADSTATE)		// 0x1f			// in ISR -- received bad state code (upper 6 bits of SMB0CN)
#define DCSC_ERR_MEAS_PARCHANPARM		MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_MEAS_PARCHANPARM)	// 0x40			// invalid parameter during attempt at channel measurement
#define DCSC_ERR_MEAS_PARSAMP			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_MEAS_PARSAMP)		// 0x41			// unmatched samping rates during attempt at parallel channel measurements
#define DCSC_ERR_PROFILE_PARSE			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_PROFILE_PARSE)		// 0x50			// trouble parsing profile
#define DCSC_ERR_PROFILE_READ			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_PROFILE_READ)		// 0x51			// trouble getting profile from memory
#define DCSC_ERR_PROFILE_WRITE			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_PROFILE_WRITE)		// 0x52			// trouble getting profile from memory
#define DCSC_ERR_MEAS_AUTOTR_FAST		MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_MEAS_AUTOTR_FAST)	// 0x53			// A measurement after auto triggering did not match up the red LED raw counts
/* Bootloader Error Returns */
#define DCSC_ERR_UNSUP_CMD				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNSUP_CMD)			// 0x70			// Unsupported command.
#define DCSC_ERR_PGM_FAILURE			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_PGM_FAILURE)			// 0x71			// FLASH reports error during programming.
#define DCSC_ERR_BAD_SIGN				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_BAD_SIGN)			// 0x72			// Signature did not match data.
#define DCSC_ERR_LOCK_FAILURE			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_LOCK_FAILURE)		// 0x73			// FLASH memory lock/unlock command failed
/* end bootloader */

#define DCSC_ERR_UNDEF_MEM_ADDR			MAKEERRCODE(3, DCSC_DEV_ERRF, ERR_DCSC_ERR_UNDEF_MEM_ADDR)		// 0x80 		   // unrecognized memory address

#define DCSC_ERR_USB_READ				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_USB_READ)			// 0x81			// USB read error
#define DCSC_ERR_USB_WRITE				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_USB_WRITE)			// 0x82			// USB write error

#define DCSC_ERR_INTERNAL_SEM			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_INTERNAL_SEM)		// 0xf0			// Could not get semaphore
#define DCSC_ERR_UNDEF_ISR1				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR1)			// 0xf1
#define DCSC_ERR_UNDEF_ISR2				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR2)			// 0xf2
#define DCSC_ERR_UNDEF_ISR3				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR3)			// 0xf3
#define DCSC_ERR_UNDEF_ISR4				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR4)			// 0xf4
////#defDEV_DCSC_ERR_UNDEF_ISR5				MAKEERRCODE(3, DCSC_DEV_ERRF, ine DEV_DCSC_ERR_UNDEF_ISR5)		// 0xf5
#define DCSC_ERR_UNDEF_ISR6				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR6)			// 0xf6
////#defDEV_DCSC_ERR_UNDEF_ISR7				MAKEERRCODE(3, DCSC_DEV_ERRF, ine DEV_DCSC_ERR_UNDEF_ISR7)		// 0xf7
////#defDEV_DCSC_ERR_UNDEF_ISR8				MAKEERRCODE(3, DCSC_DEV_ERRF, ine DEV_DCSC_ERR_UNDEF_ISR8)		// 0xf8
#define DCSC_ERR_UNDEF_ISR9				MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR9)			// 0xf9
#define DCSC_ERR_UNDEF_ISR10			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR10)			// 0xfa
#define DCSC_ERR_UNDEF_ISR11			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR11)			// 0xfb
////#defDEV_DCSC_ERR_UNDEF_ISR12			MAKEERRCODE(3, DCSC_DEV_ERRF, ine DEV_DCSC_ERR_UNDEF_ISR12)		// 0xfc
#define DCSC_ERR_UNDEF_ISR13			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR13)			// 0xfd
////#defDEV_DCSC_ERR_UNDEF_ISR14			MAKEERRCODE(3, DCSC_DEV_ERRF, ine DEV_DCSC_ERR_UNDEF_ISR14)		// 0xfe
#define DCSC_ERR_UNDEF_ISR15			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_UNDEF_ISR15)			// 0xff

#define DCSC_ERR_DEVICE_LOCKED			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_DEVICE_LOCKED)		// 0xC0
#define DCSC_ERR_STORAGE_FULL			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_STORAGE_FULL)		// 0xC1
#define DCSC_ERR_STORAGE_WRITE			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_STORAGE_WRITE)		// 0xC2
#define DCSC_ERR_STORAGE_READ			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_STORAGE_READ)		// 0xC3
#define DCSC_ERR_STORAGE_DELETE			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_STORAGE_DELETE)		// 0xC4
#define DCSC_ERR_FILE_NOT_FOUND			MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_FILE_NOT_FOUND)		// 0xC5
#define DCSC_ERR_NOT_ENOUGH_DATA		MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_NOT_ENOUGH_DATA)		// 0xC6
#define DCSC_ERR_INVALID_PASSWORD		MAKEERRCODE(3, DCSC_DEV_ERRF, DEV_DCSC_ERR_INVALID_PASSWORD)	// 0xC7



//Parameters to pass to the Calibrate function
#define CAL_WHITE	0
#define CAL_BLACK	1

//SetOutputMode values
#define	MODE_RAW			0x00
#define	MODE_LABD502		0x10
#define	MODE_LABD6510		0x11
#define	MODE_XYZD502		0x20
#define	MODE_XYZD6510		0x21

//GetDeviceType values
#define TYPE_S3P			0x01	//Spectrocolorimeter 1005
#define TYPE_S3PSR			0x02	//Spyder3Print SR Spectrocolorimeter

//Number of bands
#define	NUM_BANDS			6

//Definitions for instrument button codes
//These are passed to the button call-back function
//Button codes sent with the MSB set are physical (as oppesed to vitrual e.g. auto triggered)
#define BUTTON_IS_PHYSICAL			0x80	
#define BUTTON_CODE_MASK			(~BUTTON_IS_PHYSICAL)

#define BUTTON_1005_MEASURE			0x7A	//DC1005 measure
#define BUTTON_0308_MEASURE_LEFT	0x00	//DC0308 left measure
#define BUTTON_0308_MEASURE_RIGHT	0x01	//DC0308 right measure
#define BUTTON_0308_NAV_TOP			0x02	//DC0308 top navigation
#define BUTTON_0308_NAV_MIDDLE		0x03	//DC0308 middle navigation
#define BUTTON_0308_NAV_BOTTOM		0x04	//DC0308 bottom navigation

//Auto triggering mode constants
#define AUTO_TRIGGER_MODE_STOP						0x00
#define AUTO_TRIGGER_MODE_START						0x01
#define AUTO_TRIGGER_MODE_START_ON_BUTTON			0x02
//Auto triggering stop condition constants
#define AUTO_TRIGGER_COND_STOP_NEVER				0x10
#define AUTO_TRIGGER_COND_STOP_ON_BUTTON			0x11
#define AUTO_TRIGGER_COND_PAUSE_RESUME_ON_BUTTON	0x12
//Auto triggering hardware button flag. "OR" with
//  AUTO_TRIGGER_MODE_START_ON_BUTTON
//  AUTO_TRIGGER_COND_STOP_ON_BUTTON
//  AUTO_TRIGGER_COND_PAUSE_RESUME_ON_BUTTON
//to send the hardware button event to the host in these modes.
//In all other modes the hardware button is always sent.
#define AUTO_TRIGGER_FLAG_SEND_EVENT				0x80

#endif
