﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Threading;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Diagnostics;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        SpyderManager manager = null;

        public Form1()
        {
            InitializeComponent();
            btnClose.Enabled = false;
            btnInit.Enabled = false;
            btnLab.Enabled = false;
            btnW.Enabled = false;
            btnB.Enabled = false;
        }

        

        private void RicevutoLAB(string sData)
        {
            Control.CheckForIllegalCrossThreadCalls = false; // importante per EF4
            txtLog.Text = txtLog.Text + Environment.NewLine + sData;
        }

        private void NERO() { MessageBox.Show("NERO CALIBRATO"); }

        private void BIANCO() { MessageBox.Show("BIANCO CALIBRATO"); }

        private void INIZIALIZZATO(string data) 
        { 
            if(data == "")
                MessageBox.Show("Risultato: OK!");
            else
                MessageBox.Show("Risultato: " + data);
        }

        private void ERROR(string error) { MessageBox.Show(error); }

        private void btnLeggiLAB_Click(object sender, EventArgs e)
        {
            //verificare inizializzazione eseguita
            manager.CIELabRequest();
        }

        
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            btnCloseEF4_Click(null, null);
        }

        private void CalibraBianco_Click(object sender, EventArgs e)
        {
            manager.WhiteCalibrationRequest();
        }

        private void CalibraNero_Click(object sender, EventArgs e)
        {
            manager.BlackCalibrationRequest();
        }

        private void Inizializza_Click(object sender, EventArgs e)
        {
            manager.DeviceInitRequest();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtLog.Text = "";
        }

        private void btnOpenEF4_Click(object sender, EventArgs e)
        {
            manager = new SpyderManager(8888, Directory.GetCurrentDirectory() + "\\Select.exe");
            manager.StartService();
            manager.DataReceived += new SpyderManager.DeviceDataReceivedEventHandler(RicevutoLAB);
            manager.BlackCalibrated += new SpyderManager.BlackCalibrationEventHandler(NERO);
            manager.WhiteCalibrated += new SpyderManager.WhiteCalibrationEventHandler(BIANCO);
            manager.Initialized += new SpyderManager.InitializationEventHandler(INIZIALIZZATO);
            manager.DeviceError += new SpyderManager.ErrorDeviceEventHandler(ERROR);
            btnOpen.Enabled = false;
            btnInit.Enabled = true;
            btnClose.Enabled = true;
            btnLab.Enabled = true;
            btnW.Enabled = true;
            btnB.Enabled = true;
        }

        private void btnCloseEF4_Click(object sender, EventArgs e)
        {
            if (manager != null)
            {
                if (manager.IsServiceRunning)
                {
                    manager.StopService();
                }
            }
            btnOpen.Enabled = true;
            btnInit.Enabled = false;
            btnClose.Enabled = false;
            btnLab.Enabled = false;
            btnW.Enabled = false;
            btnB.Enabled = false;
        }

        
    }
}
