﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLog = new System.Windows.Forms.TextBox();
            this.btnLab = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnW = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnInit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(13, 146);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(476, 286);
            this.txtLog.TabIndex = 1;
            // 
            // btnLab
            // 
            this.btnLab.Location = new System.Drawing.Point(142, 10);
            this.btnLab.Name = "btnLab";
            this.btnLab.Size = new System.Drawing.Size(118, 36);
            this.btnLab.TabIndex = 3;
            this.btnLab.Text = "READ LAB";
            this.btnLab.UseVisualStyleBackColor = true;
            this.btnLab.Click += new System.EventHandler(this.btnLeggiLAB_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(128, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "SIMULAZIONE EUROFORMULATIONS 4";
            // 
            // btnW
            // 
            this.btnW.Location = new System.Drawing.Point(6, 52);
            this.btnW.Name = "btnW";
            this.btnW.Size = new System.Drawing.Size(130, 44);
            this.btnW.TabIndex = 7;
            this.btnW.Text = "CAL. WHITE";
            this.btnW.UseVisualStyleBackColor = true;
            this.btnW.Click += new System.EventHandler(this.CalibraBianco_Click);
            // 
            // btnB
            // 
            this.btnB.Location = new System.Drawing.Point(142, 52);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(118, 44);
            this.btnB.TabIndex = 8;
            this.btnB.Text = "CAL.BLACK";
            this.btnB.UseVisualStyleBackColor = true;
            this.btnB.Click += new System.EventHandler(this.CalibraNero_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(13, 438);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "RESET";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(13, 38);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(99, 102);
            this.btnOpen.TabIndex = 10;
            this.btnOpen.Text = "OPEN EF4";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpenEF4_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(390, 38);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(99, 102);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "CLOSE EF4";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnCloseEF4_Click);
            // 
            // btnInit
            // 
            this.btnInit.Location = new System.Drawing.Point(6, 10);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(130, 36);
            this.btnInit.TabIndex = 12;
            this.btnInit.Text = "INIT";
            this.btnInit.UseVisualStyleBackColor = true;
            this.btnInit.Click += new System.EventHandler(this.Inizializza_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLab);
            this.groupBox1.Controls.Add(this.btnInit);
            this.groupBox1.Controls.Add(this.btnW);
            this.groupBox1.Controls.Add(this.btnB);
            this.groupBox1.Location = new System.Drawing.Point(118, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 102);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 473);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtLog);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Button btnLab;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnW;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnInit;
        private System.Windows.Forms.GroupBox groupBox1;

    }
}

