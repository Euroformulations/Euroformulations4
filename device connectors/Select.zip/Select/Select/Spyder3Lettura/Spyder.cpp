#include "DCSCAPI.h"
#include <conio.h>  // dello spyder, solo windows
#include <thread>
#include<string>
#include "HandleSrvnet.cpp"
#include <mutex>
#include<iostream>
#define WIN32_LEAN_AND_MEAN

using namespace std;

HandleSrvnet* conn_send;
flt_structMeasData *meas;
string dispositivoPronto = "not initialized";
std::mutex mtx;
string GetError(long error);
bool bListenerClosedWithError = false;

enum eProgramExitStatus
{
	STATUS_OK = 0,
	SENDER_CHANNEL_ERROR = 1,
	SENDER_CHANNEL_ACK_ERROR = 2,
	RECEIVER_CHANNEL_ERROR = 3,
	RECEIVER_CHANNEL_ACK_ERROR = 4,
	NO_PORT_SPECIFIED = 5,
	LISTENER_CLOSED_WITH_ERROR = 6
};



void ButtonPressed(int buttonID)
{
	string risp = "";
	mtx.lock();
	try
	{
		long errore;
		if (errore = DCSC_Measure(meas))
		{
			string err = GetError(errore);
			risp = "err\t" + err;
		}
		else
		{
			risp = "lab\t" + to_string(meas->L) + "\t" + to_string(meas->a) + "\t" + to_string(meas->b);
		}
	}
	catch (const std::exception &e)
	{
		string data = e.what();
		string risp = "err\t" + data;
	}
	mtx.unlock();
	try
	{
		conn_send->Send(risp);
	}
	catch (...){}
}

string InitializeDevice()
{
	try
	{
		long error;

		//Spyder connection
		DCSC_CloseConnection();
		if ((error = DCSC_OpenConnection()))
		{
			return "initerr\t" + GetError(error);
		}

		//Spyder auth
		if ((error = DCSC_Authorize("876710-316300-28", 1)))
		{
			return "initerr\t" + GetError(error);
		}
		//   To make a measurement first set the desired output mode. The available
		//   modes are:
		//   MODE_RAW		- RAW A/D converter values from the 6 channels
		//   MODE_LABD502	- CIE L*a*b* values for D50/2 degrees illuminant/observer
		//   MODE_LABD6510	- CIE L*a*b* values for D65/10 degrees illuminant/observer 
		//   MODE_XYZD502	- XYZ values for D50/2 degrees illuminant/observer
		//   MODE_XYZD6510	- XYZ values for D65/10 degrees illuminant/observer
		if ((error = DCSC_SetOutputMode(MODE_LABD6510)))
		{
			return "initerr\t" + GetError(error);
		}

		DCSC_SetButtonCallBack(ButtonPressed);

		meas = (flt_structMeasData *)malloc(sizeof(flt_structMeasData));

		return "";
	}
	catch (const std::exception &ex)
	{
		try { DCSC_CloseConnection(); }
		catch (...){}
		string errorData = ex.what();
		return "initerr\t" + errorData;
	}
}

void JobListener(HandleSrvnet* conn) 
{
	try
	{
		bool bStop = false;
		string risp;
		while (!bStop)
		{
			risp = "";
			string comm = conn->Receive();
			if (comm == "stop")
			{
				bStop = true;
			}
			else
			{
				mtx.lock();
				try
				{
					long error;
					if (comm == "lab")
					{
						if (dispositivoPronto != "")
						{
							dispositivoPronto = InitializeDevice();
						}
						if (dispositivoPronto != "")
						{
							//error
							risp = dispositivoPronto;
						}
						else
						{
							if ((error = DCSC_Measure(meas)))
							{
								string err = GetError(error);
								risp = "err\t" + to_string(error);
							}
							else
							{
								risp = "lab\t" + to_string(meas->L) + "\t" + to_string(meas->a) + "\t" + to_string(meas->b);
							}
						}
					}
					else if (comm == "white")
					{
						if (dispositivoPronto != "")
						{
							dispositivoPronto = InitializeDevice();
						}
						if (dispositivoPronto != "")
						{
							//error
							risp = dispositivoPronto;
						}
						else
						{
							if ((error = DCSC_Calibrate(CAL_WHITE)))
							{
								string err = GetError(error);
								risp = "err\t" + err;
							}
							else
							{
								risp = "white_done";
							}
						}
					}
					else if (comm == "black")
					{
						if (dispositivoPronto != "")
						{
							dispositivoPronto = InitializeDevice();
						}
						if (dispositivoPronto != "")
						{
							//error
							risp = dispositivoPronto;
						}
						else
						{
							if ((error = DCSC_Calibrate(CAL_BLACK)))
							{
								string err = GetError(error);
								risp = "err\t" + err;
							}
							else
							{
								risp = "black_done";
							}
						}
					}
					else if (comm == "init")
					{
						dispositivoPronto = InitializeDevice();
						risp = "statusInit\t" + dispositivoPronto;
					}
					else
					{
						risp = "err\tunknown command " + comm;
					}
				}
				catch (...){}
				mtx.unlock();

				try
				{
					conn->Send(risp);
				}
				catch (...){}
			}
		}
	}
	catch (...)
	{
		bListenerClosedWithError = true;
	}
}

static string GetError(long error)
{
	wchar_t errmsg[129];
	DCSC_GetErrorMessage(error, errmsg, 128);
	wstring ws(errmsg);
	string str(ws.begin(), ws.end());
	return str;
}

int main(int argc, char* argv[])
{
	if (sizeof(argv) < 2) { return NO_PORT_SPECIFIED; }
	PCSTR port = argv[1];
	
	cout << "entro" << endl;
	//apro canale di invio
	conn_send = new HandleSrvnet(port);
	if (conn_send->Connect())
	{
		conn_send->Send("s");
		string ack = conn_send->Receive();
		if (ack != "ok") { return SENDER_CHANNEL_ACK_ERROR; }
	}
	else
	{
		return SENDER_CHANNEL_ERROR;
	}

	//apro canale in ricezione
	HandleSrvnet* conn_recv = new HandleSrvnet(port);
	if (conn_recv->Connect())
	{
		conn_recv->Send("r");
		string ack2 = conn_recv->Receive();
		if (ack2 != "ok") { return RECEIVER_CHANNEL_ACK_ERROR; }
	}
	else
	{
		return RECEIVER_CHANNEL_ERROR;
	}
	thread tListener = thread(JobListener, conn_recv);

	//inizializzo dispositivo comunicando eventuali errori
	dispositivoPronto = InitializeDevice();
	if (dispositivoPronto != "")
	{
		//error
		conn_send->Send(dispositivoPronto);
	}

	tListener.join();

	//chiudo connessione con il dispositivo
	DCSC_CloseConnection();

	if (bListenerClosedWithError)
	{
		return LISTENER_CLOSED_WITH_ERROR;
	}
	else
	{
		return STATUS_OK;
	}
}
