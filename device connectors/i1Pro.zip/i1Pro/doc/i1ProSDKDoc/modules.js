var modules =
[
    [ "Result Type", "group__result_type.html", "group__result_type" ],
    [ "Key and Value Definitions", "group__keys.html", "group__keys" ],
    [ "Device Handling", "group__device.html", "group__device" ],
    [ "Get/Set Device Options", "group__conditions.html", "group__conditions" ],
    [ "Connection & Button Status", "group__status.html", "group__status" ],
    [ "Calibrate & Trigger Measurement", "group__cal__meas.html", "group__cal__meas" ],
    [ "Measurement Results", "group__results.html", "group__results" ],
    [ "Device Events", "group__event.html", "group__event" ]
];