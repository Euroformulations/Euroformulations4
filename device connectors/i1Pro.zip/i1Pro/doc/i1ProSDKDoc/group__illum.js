var group__illum =
[
    [ "I1_AVAILABLE_ILLUMINATIONS_KEY", "group__illum.html#ga2897f4bf1a2559e358f6b4e78a2bed6d", null ],
    [ "I1_AVAILABLE_RESULT_INDEXES_KEY", "group__illum.html#ga9febb58f8591b80bb8978006458f061b", null ],
    [ "I1_RESULT_INDEX_KEY", "group__illum.html#gaeb9fafbf1da29699f5a87d9047887cc5", null ],
    [ "I1_ILLUMINATION_CONDITION_M0", "group__illum.html#ga68c387eab745c9c93974042655fdab72", null ],
    [ "I1_ILLUMINATION_CONDITION_M1", "group__illum.html#ga42571efb6a3745aac6a1ae68a2287e6a", null ],
    [ "I1_ILLUMINATION_CONDITION_M2", "group__illum.html#ga4e733282659bf1c9b764d5286c6baa9f", null ],
    [ "I1_EMISSIVE", "group__illum.html#ga496170dfe46c30d671fb982a6a0222a4", null ]
];