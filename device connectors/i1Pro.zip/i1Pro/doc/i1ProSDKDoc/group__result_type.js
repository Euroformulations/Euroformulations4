var group__result_type =
[
    [ "I1_ResultType", "group__result_type.html#gac4d29fecb64f4aeaa001f8cd7b8a5c60", [
      [ "eNoError", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba8c8e213ecccbb012954699a9b224bf2d", null ],
      [ "eException", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55baa49af1964fbbd380c45680ea97c69eff", null ],
      [ "eBadBuffer", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba6039adda908f183487042a32eedd0b45", null ],
      [ "eInvalidHandle", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55bacb9ead2fb2c1828813636188eb1061f9", null ],
      [ "eInvalidArgument", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba93fa9ad52d088e8c57e94ceb883e9cff", null ],
      [ "eDeviceNotOpen", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba302f77305dd4dc7d44e78d318132da3f", null ],
      [ "eDeviceNotConnected", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55bae6af08091495d5c83de418c79cd55625", null ],
      [ "eDeviceNotCalibrated", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba5505e6801d4b90ba59f5b9e193342ae2", null ],
      [ "eNoDataAvailable", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba3960fe8a21e19aaa3a4b1535d105fc47", null ],
      [ "eNoMeasureModeSet", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55baadda5265149a3607e860432f5f5e797b", null ],
      [ "eNoReferenceChartLine", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55bae944393e422b98af9e973a553acc357c", null ],
      [ "eNoSubstrateWhite", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55bae076c390f8a894bf15c569952225568c", null ],
      [ "eNotLicensed", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba6398688bb6aee52886b731b0886e2ed7", null ],
      [ "eDeviceAlreadyOpen", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba7e80219b126bd1f3aefff35643d6b88d", null ],
      [ "eDeviceAlreadyInUse", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba014fb7a30205354bfb324d573b4c7d36", null ],
      [ "eDeviceCommunicationError", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba759684df77a637e4f0b396abb20b2c19", null ],
      [ "eUSBPowerProblem", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba98fa156ac5ce0c8ed98531c3591a2d1d", null ],
      [ "eNotOnWhiteTile", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba81f54736bba86def7a3580f4ec8a0f74", null ],
      [ "eStripRecognitionFailed", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba048bac7e4dd9b8ff4d8be041409cc3c6", null ],
      [ "eChartCorrelationFailed", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba403c168696d04620586f24cd9aa29071", null ],
      [ "eInsufficientMovement", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba0fd60c3bb18a6af289ff776a7ce61b6d", null ],
      [ "eExcessiveMovement", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba5c7aba455fc0aff9c798fb5ce436cfe8", null ],
      [ "eEarlyScanStart", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba9e22b4883f6864b7e16b6f487be97028", null ],
      [ "eUserTimeout", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba8d7cef847d04624db64240c2f4f7a30c", null ],
      [ "eIncompleteScan", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55bacb7747a1b62f52dbad1a8f4afc67a992", null ],
      [ "eDeviceNotMoved", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55baa53347bae4a4338d48e00ab547900634", null ],
      [ "eDeviceCorrupt", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55ba589ad8ca75a6c450fbaddda9bf623db5", null ],
      [ "eWavelengthShift", "group__result_type.html#gga06fc87d81c62e9abb8790b6e5713c55bad503c32ff29be3e74b2c496c8ae00ff8", null ]
    ] ]
];