var group__event =
[
    [ "I1_DeviceEvent", "group__event.html#ga909f0466695ec9f00bd68bb48d2d7d5e", null ],
    [ "FPtr_I1_DeviceEventHandler", "group__event.html#gae1fc325dc20b7a91d8d7f78768436b87", [
      [ "eI1ProArrival", "group__event.html#ggabc6126af1d45847bc59afa0aa3216b04a1804e809b63e08c090022c08d9000426", null ],
      [ "eI1ProDeparture", "group__event.html#ggabc6126af1d45847bc59afa0aa3216b04a6fff38d3480bfc81af777eec7fc82730", null ],
      [ "eI1ProButtonPressed", "group__event.html#ggabc6126af1d45847bc59afa0aa3216b04a4b2c7f498578ef1fd709023374f7fe25", null ],
      [ "eI1ProScanReadyToMove", "group__event.html#ggabc6126af1d45847bc59afa0aa3216b04ab16af2152b9412a02daea3cd0dffa570", null ],
      [ "eI1ProLampRestore", "group__event.html#ggabc6126af1d45847bc59afa0aa3216b04a41b794d9740a2b9251f4fc6143d2e611", null ]
    ] ],
    [ "I1_RegisterDeviceEventHandler", "group__event.html#ga3cb4c05f07f817de28aa436e4649b45a", null ]
];