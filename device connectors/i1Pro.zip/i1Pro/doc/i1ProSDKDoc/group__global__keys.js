var group__global__keys =
[
    [ "I1_SDK_VERSION", "group__global__keys.html#ga44b71451c7e7cc3e0db8eaebf06b3e16", null ],
    [ "I1_SDK_VERSION_MAJOR", "group__global__keys.html#ga22ff2555fe1d31d22b8166692daf5a87", null ],
    [ "I1_SDK_VERSION_MINOR", "group__global__keys.html#gaabdae6b245aa136d74cd99469105ffd1", null ],
    [ "I1_SDK_VERSION_REVISION", "group__global__keys.html#ga14c278d740d8882493ea395b85c090cf", null ],
    [ "I1_SDK_VERSION_BUILD", "group__global__keys.html#gae05bce0ad341d6f3cc74e79339c1a873", null ],
    [ "I1_SDK_VERSION_SUFFIX", "group__global__keys.html#gaf6c077683568bc362160067bda1573b5", null ],
    [ "I1_LAST_ERROR", "group__global__keys.html#ga89cf7bc1fe3a1422c1c97beaa8821983", null ],
    [ "I1_LAST_ERROR_TEXT", "group__global__keys.html#ga7c1b1001541b9a0971dcc87ecc575464", null ],
    [ "I1_LAST_ERROR_NUMBER", "group__global__keys.html#ga382e6195863aa66ef68ed6dcfe2e72d1", null ],
    [ "I1_ON_MEASUREMENT_SUCCESS_NO_LED_INDICATION", "group__global__keys.html#ga7a2a5e3375b541573ed190592e9d9afe", null ]
];