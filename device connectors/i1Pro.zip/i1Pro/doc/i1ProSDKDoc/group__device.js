var group__device =
[
    [ "I1_DeviceHandle", "group__device.html#ga85b40169afbb9c7fff109e963ef939dd", null ],
    [ "I1_GetDevices", "group__device.html#ga42150bb23dd290e52672a700ad6bf818", null ],
    [ "I1_OpenDevice", "group__device.html#ga6df59e8c4104e90e1931b6cdff697064", null ],
    [ "I1_CloseDevice", "group__device.html#gae26a9a52058d4f3f703bc2b450114b3a", null ]
];