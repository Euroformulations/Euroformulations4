var group__scan__dir =
[
    [ "I1_SCAN_DIRECTION_KEY", "group__scan__dir.html#gaf6bfb031642330c6bf1121006eaaf647", null ],
    [ "I1_SCAN_DIRECTION_FORWARD", "group__scan__dir.html#ga68f187add4d85993c64df5bb73c1f7ba", null ],
    [ "I1_SCAN_DIRECTION_BACKWARD", "group__scan__dir.html#ga3d1bea7683240c0fa00549bbb30ba4a9", null ],
    [ "I1_SCAN_DIRECTION_UNDEFINED", "group__scan__dir.html#gaf9b08bd4fce5a34ec5d2ec1e1f5717ba", null ],
    [ "I1_NUMBER_OF_PATCHES_PER_LINE", "group__scan__dir.html#gad08785abd9ba6588da7557c2b30c4299", null ],
    [ "I1_LAST_SCAN_DIRECTION_KEY", "group__scan__dir.html#ga9f31406be4cf96e913699cc592bc4e91", null ],
    [ "I1_LAST_SCAN_RIGHT_TO_LEFT", "group__scan__dir.html#ga3fb098fa1108dc8a9ff8dae76a427a05", null ],
    [ "I1_LAST_SCAN_LEFT_TO_RIGHT", "group__scan__dir.html#gaa4342897d54de2d34248a30225049561", null ],
    [ "I1_LAST_SCAN_UNDEFINED", "group__scan__dir.html#gad97b8bcd3f32a3c279823b958269c8d3", null ]
];