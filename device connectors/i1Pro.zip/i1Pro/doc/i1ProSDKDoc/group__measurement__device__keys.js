var group__measurement__device__keys =
[
    [ "Patch Recognition", "group__patch__recog.html", "group__patch__recog" ],
    [ "Reference Charts", "group__ref__chart.html", "group__ref__chart" ],
    [ "Scan Direction", "group__scan__dir.html", "group__scan__dir" ],
    [ "Indicator LED", "group__ind__led.html", "group__ind__led" ],
    [ "Illuminants", "group__illum.html", "group__illum" ],
    [ "I1_LOW_RESOLUTION_KEY", "group__measurement__device__keys.html#ga9b104f6cde079b858d3c728197618d17", null ],
    [ "I1_ADAPTIVE_MEASUREMENT_KEY", "group__measurement__device__keys.html#ga0cbd3fb0e613805916aebd7703617932", null ],
    [ "I1_TIME_SINCE_LAST_CALIBRATION", "group__measurement__device__keys.html#ga1ed20815b6365e02b53d7ea1d1d40ae1", null ],
    [ "I1_TIME_UNTIL_CALIBRATION_EXPIRE", "group__measurement__device__keys.html#ga1c28e454e8e0e5020dd3988628ee7c0b", null ],
    [ "I1_MEASURE_COUNT", "group__measurement__device__keys.html#ga36606f09c6ea75968731e6871669fd10", null ],
    [ "I1_LAST_AUTO_DENSITY_FILTER", "group__measurement__device__keys.html#ga926bc7a9812ecd0494819e002e41f115", null ],
    [ "I1_MEASUREMENT_GEOMETRY_KEY", "group__measurement__device__keys.html#ga8f86a275a8e1dd06413f9f2004de274d", null ],
    [ "I1_MEASUREMENT_GEOMETRY_45_0", "group__measurement__device__keys.html#ga2470b3788753fb65a53c5ae4db5aa8f5", null ]
];