var group__status =
[
    [ "I1_ConnectionStatusType", "group__status.html#gaef42f1a76f6e995d32d02e65999e940d", null ],
    [ "I1_ButtonStatusType", "group__status.html#ga35c38c0918320a9c882fb13e575eaebe", [
      [ "eInvalidConnectionHandle", "group__status.html#ggadf764cbdea00d65edcd07bb9953ad2b7a43e290d8faa3a687bd08534c704f1794", null ],
      [ "eI1ProClosed", "group__status.html#ggadf764cbdea00d65edcd07bb9953ad2b7aad2bf8c584a1a30a5ac399fdb6eaee35", null ],
      [ "eI1ProOpen", "group__status.html#ggadf764cbdea00d65edcd07bb9953ad2b7a605db27b4aa642461d575403d55ec27f", null ],
      [ "eButtonIsPressed", "group__status.html#gga99fb83031ce9923c84392b4e92f956b5a720a79d5157750157705e82b00f75d82", null ],
      [ "eButtonNotPressed", "group__status.html#gga99fb83031ce9923c84392b4e92f956b5a0f6505ef4970e19a622f4668bae64a8a", null ]
    ] ],
    [ "I1_GetConnectionStatus", "group__status.html#gad19678ecc4e126027755fe71c8654081", null ],
    [ "I1_GetButtonStatusD", "group__status.html#gac0b01c9d9fec5438a9e478523c6221df", null ]
];