var group__devcap__keys =
[
    [ "I1_HAS_UV_LED_KEY", "group__devcap__keys.html#gad2f9d308bbe60d86f08621bbcfd26da2", null ],
    [ "I1_HAS_UVCUT_FILTER_KEY", "group__devcap__keys.html#gae350811ab361d4726e203fc305214d9e", null ],
    [ "I1_HAS_WAVELENGTH_LED_KEY", "group__devcap__keys.html#gae8e648cb961fdc1b53a5c5adf225f534", null ],
    [ "I1_HAS_ZEBRA_RULER_SENSOR_KEY", "group__devcap__keys.html#ga85c253d28ecaa87dc63c998a0336b221", null ],
    [ "I1_HAS_INDICATOR_LED_KEY", "group__devcap__keys.html#gaf9310d3201dba32d32c99e85792417f5", null ],
    [ "I1_HAS_AMBIENT_LIGHT_KEY", "group__devcap__keys.html#ga0ca59e88ae45563db643b2260cb2750d", null ],
    [ "I1_HAS_LOW_RESOLUTION_KEY", "group__devcap__keys.html#gacf7440f53ec2f6f362def9bb4b328e7a", null ],
    [ "I1_MAX_RULER_LENGTH_KEY", "group__devcap__keys.html#ga4784694888e64c3dddcfc1112933c21e", null ],
    [ "I1_IS_EMISSION_ONLY_KEY", "group__devcap__keys.html#ga707b0a4174c76a6d4ae1e205dce3e090", null ],
    [ "I1_HW_REVISION_KEY", "group__devcap__keys.html#ga7ae39aeeb6313377f8fe53ce48caaf47", null ],
    [ "I1_SUPPLIER_NAME_KEY", "group__devcap__keys.html#ga7f3a22eff125c28749418f595cfddb13", null ],
    [ "I1_DEVICE_TYPE_KEY", "group__devcap__keys.html#ga21944b4bb8aef7aab79920396e97cdd7", null ],
    [ "I1_DEVICE_TYPE_I1PRO", "group__devcap__keys.html#gabc9e65051bf284f791713d2173cdf97e", null ]
];