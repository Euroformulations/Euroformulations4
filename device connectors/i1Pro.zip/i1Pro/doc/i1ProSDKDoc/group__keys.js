var group__keys =
[
    [ "Global Keys and Values", "group__global__keys.html", "group__global__keys" ],
    [ "Device Keys and Values", "group__device__keys.html", "group__device__keys" ],
    [ "I1_VALUE_DELIMITER", "group__keys.html#gaf61a9c435da74b73121da15695ab8e76", null ],
    [ "I1_YES", "group__keys.html#ga1a7eb6d6ee1c7181644a71d0c8ef3ad9", null ],
    [ "I1_NO", "group__keys.html#ga3d99dc541c6c16e2391448ac781b9fa3", null ],
    [ "I1_RESET", "group__keys.html#gadd7e94d9f7fc1d21e5f62b8dfddeb30b", null ],
    [ "I1_ALL", "group__keys.html#ga39ee2a6c8b461929f43a8e5265888c36", null ]
];