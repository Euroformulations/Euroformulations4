var group__patch__recog =
[
    [ "I1_AVAILABLE_PATCH_RECOGNITIONS_KEY", "group__patch__recog.html#gacd920d78c2d9e325f45902ce527fb2da", null ],
    [ "I1_PATCH_RECOGNITION_KEY", "group__patch__recog.html#ga6f939c3aa066663f79289b34ce3f4d08", null ],
    [ "I1_PATCH_RECOGNITION_DISABLED", "group__patch__recog.html#ga7122258c0a8fbdcc2473370222883b48", null ],
    [ "I1_PATCH_RECOGNITION_BASIC", "group__patch__recog.html#ga46a2ef1424853a22c891a39306ec7207", null ],
    [ "I1_PATCH_RECOGNITION_CORRELATION", "group__patch__recog.html#gad607588b2ef0b29b1f7e108eabd6c380", null ],
    [ "I1_PATCH_RECOGNITION_POSITION", "group__patch__recog.html#ga4f226b1a6a622290e068eb95f5846f33", null ],
    [ "I1_PATCH_RECOGNITION_FLASH", "group__patch__recog.html#gabdabb6340e76366623e7d53d70c9919d", null ],
    [ "I1_PATCH_RECOGNITION_RECOGNIZED_PATCHES", "group__patch__recog.html#ga0b932e37f3e0e2043b5790fa0dfd3d64", null ]
];