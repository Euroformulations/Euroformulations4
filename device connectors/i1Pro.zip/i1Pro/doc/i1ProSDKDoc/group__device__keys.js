var group__device__keys =
[
    [ "Measurement Modes", "group__measurement__mode__kv.html", "group__measurement__mode__kv" ],
    [ "Device Capability Keys", "group__devcap__keys.html", "group__devcap__keys" ],
    [ "Device Behaviors", "group__measurement__device__keys.html", "group__measurement__device__keys" ],
    [ "I1_SERIAL_NUMBER", "group__device__keys.html#gaa21e1bab5d94a8767a86bcd629be421e", null ],
    [ "I1_PRECISION_CALIBRATION_KEY", "group__device__keys.html#ga5c5a2fb55a63910ccf9e5ebd6e6807d4", null ],
    [ "I1_SIMULATE_LAMP_RESTORE_KEY", "group__device__keys.html#ga26ad30966040bd53f76e24fa3df1ce82", null ],
    [ "I1_DEVICE_PATH_KEY", "group__device__keys.html#gaa8829d3e16d6d9f3652d30b06b2fc712", null ]
];