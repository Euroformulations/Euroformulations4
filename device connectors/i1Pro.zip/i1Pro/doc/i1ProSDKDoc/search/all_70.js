var searchData=
[
  ['patch_20recognition',['Patch Recognition',['../group__patch__recog.html',1,'']]]
];
