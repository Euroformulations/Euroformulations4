var searchData=
[
  ['get_2fset_20device_20options',['Get/Set Device Options',['../group__conditions.html',1,'']]],
  ['global_20keys_20and_20values',['Global Keys and Values',['../group__global__keys.html',1,'']]]
];
