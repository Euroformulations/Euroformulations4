var searchData=
[
  ['key_20and_20value_20definitions',['Key and Value Definitions',['../group__keys.html',1,'']]]
];
