var searchData=
[
  ['reference_20charts',['Reference Charts',['../group__ref__chart.html',1,'']]],
  ['result_20type',['Result Type',['../group__result_type.html',1,'']]]
];
