var searchData=
[
  ['device_20capability_20keys',['Device Capability Keys',['../group__devcap__keys.html',1,'']]],
  ['device_20handling',['Device Handling',['../group__device.html',1,'']]],
  ['device_20keys_20and_20values',['Device Keys and Values',['../group__device__keys.html',1,'']]],
  ['device_20events',['Device Events',['../group__event.html',1,'']]],
  ['device_20behaviors',['Device Behaviors',['../group__measurement__device__keys.html',1,'']]]
];
