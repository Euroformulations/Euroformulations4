var searchData=
[
  ['tristimulus_5fsize',['TRISTIMULUS_SIZE',['../_measurement_conditions_8h.html#a45f88fc89553efce79e3d578cfdd0095',1,'MeasurementConditions.h']]]
];
