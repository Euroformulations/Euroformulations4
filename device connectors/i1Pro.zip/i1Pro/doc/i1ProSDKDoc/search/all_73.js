var searchData=
[
  ['scan_20direction',['Scan Direction',['../group__scan__dir.html',1,'']]],
  ['spectrum_5fsize',['SPECTRUM_SIZE',['../_measurement_conditions_8h.html#a86e2542d27f370cb98ed6407337f8d50',1,'MeasurementConditions.h']]]
];
