var searchData=
[
  ['observer_5fkey',['OBSERVER_KEY',['../_measurement_conditions_8h.html#a21f8518617cf467009dbad0c313e3108',1,'MeasurementConditions.h']]],
  ['observer_5ften_5fdegree',['OBSERVER_TEN_DEGREE',['../_measurement_conditions_8h.html#a42b8df24c12adf02f0dd098633b0f69c',1,'MeasurementConditions.h']]],
  ['observer_5ftwo_5fdegree',['OBSERVER_TWO_DEGREE',['../_measurement_conditions_8h.html#a26165397dac9d43b0a8530cd190c2b0c',1,'MeasurementConditions.h']]]
];
