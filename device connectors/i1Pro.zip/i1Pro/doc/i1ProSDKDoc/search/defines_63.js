var searchData=
[
  ['color_5fspace_5fcie_5fuv_5fy1960',['COLOR_SPACE_CIE_UV_Y1960',['../_measurement_conditions_8h.html#a96a5e199deaaab2248162b46212b3e09',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fcie_5fuv_5fy1976',['COLOR_SPACE_CIE_UV_Y1976',['../_measurement_conditions_8h.html#ab77789ad4ec51a86f6d6314fcc239f67',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fcielab',['COLOR_SPACE_CIELab',['../_measurement_conditions_8h.html#a9e9e0151b506d67385fc752dcd5efe8b',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fcielch',['COLOR_SPACE_CIELCh',['../_measurement_conditions_8h.html#aadf9d57c90b1853a9ea15b7cc342353e',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fcielchuv',['COLOR_SPACE_CIELChuv',['../_measurement_conditions_8h.html#af08af0b2d53ae317d5723d2b7ea9cffc',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fcieluv',['COLOR_SPACE_CIELuv',['../_measurement_conditions_8h.html#ad53c7a52c9b38da4301cd82744758b8b',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fciexyy',['COLOR_SPACE_CIExyY',['../_measurement_conditions_8h.html#a8797a28ca6d6cab5ea05d5c661e7ec77',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fciexyz',['COLOR_SPACE_CIEXYZ',['../_measurement_conditions_8h.html#a3abc19e12c26baa0dafef56b003165e2',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fhunterlab',['COLOR_SPACE_HunterLab',['../_measurement_conditions_8h.html#a400c561758cc56fbe7b89a104ffbf233',1,'MeasurementConditions.h']]],
  ['color_5fspace_5fkey',['COLOR_SPACE_KEY',['../_measurement_conditions_8h.html#ab3f9f397796debc88a60aea2dfad3949',1,'MeasurementConditions.h']]],
  ['color_5fspace_5flab_5fmg',['COLOR_SPACE_LAB_MG',['../_measurement_conditions_8h.html#afa18a3c780c2f1635701d6ca08618b11',1,'MeasurementConditions.h']]],
  ['color_5fspace_5flch_5fmg',['COLOR_SPACE_LCH_MG',['../_measurement_conditions_8h.html#a922a51efe88b3b7f29d637aa42fe7cb3',1,'MeasurementConditions.h']]],
  ['color_5fspace_5frgb',['COLOR_SPACE_RGB',['../_measurement_conditions_8h.html#a120427965342fa8c76aee63406195827',1,'MeasurementConditions.h']]],
  ['color_5fspace_5frxryrz',['COLOR_SPACE_RXRYRZ',['../_measurement_conditions_8h.html#a94c6ad0f5da740f4d8cbe8679f316e0f',1,'MeasurementConditions.h']]]
];
