var searchData=
[
  ['wave_5flength_5f380',['WAVE_LENGTH_380',['../_measurement_conditions_8h.html#a8c4e13e14dbf54c2b3fba1189a2ca827',1,'MeasurementConditions.h']]],
  ['wave_5flength_5f730',['WAVE_LENGTH_730',['../_measurement_conditions_8h.html#a733d2996fd23b56855240eb6193ed855',1,'MeasurementConditions.h']]],
  ['white_5fbase_5fabsolute',['WHITE_BASE_ABSOLUTE',['../_measurement_conditions_8h.html#a3637c0bb286f451caa7a3634c891488d',1,'MeasurementConditions.h']]],
  ['white_5fbase_5fautomatic',['WHITE_BASE_AUTOMATIC',['../_measurement_conditions_8h.html#ac39206e2c8d9e5a0eaf49660ba42a8c3',1,'MeasurementConditions.h']]],
  ['white_5fbase_5fkey',['WHITE_BASE_KEY',['../_measurement_conditions_8h.html#a64de7806de5dd50b9c18fff96dc51b1a',1,'MeasurementConditions.h']]],
  ['white_5fbase_5fpaper',['WHITE_BASE_PAPER',['../_measurement_conditions_8h.html#a34b325dfd3b562c800f56d068d752ed3',1,'MeasurementConditions.h']]]
];
