var group__conditions =
[
    [ "I1_SetGlobalOption", "group__conditions.html#gaf7262790f87edd1277e34eb736e2633b", null ],
    [ "I1_GetGlobalOption", "group__conditions.html#ga778a0dc41daf280ac9a6bd34650b0ec5", null ],
    [ "I1_GetGlobalOptionD", "group__conditions.html#ga87aede67217b0274a86f586f33dd6422", null ],
    [ "I1_SetOption", "group__conditions.html#gaf3571c1f111707767c2c6a289f4a39fe", null ],
    [ "I1_GetOption", "group__conditions.html#ga55abdf3c9a9c006b2cfc2e1cbcdc690d", null ],
    [ "I1_GetOptionD", "group__conditions.html#ga94d54cd4f0496d880967fa4f73a068f1", null ]
];