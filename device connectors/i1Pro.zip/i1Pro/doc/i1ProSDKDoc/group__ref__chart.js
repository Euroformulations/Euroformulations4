var group__ref__chart =
[
    [ "I1_REFERENCE_CHART_COLOR_SPACE_KEY", "group__ref__chart.html#ga323effd374fd3569d469e59f5a432e03", null ],
    [ "I1_REFERENCE_CHART_RGB", "group__ref__chart.html#ga0c5406d9880afa717cb6c0a3062004ee", null ],
    [ "I1_REFERENCE_CHART_CMYK", "group__ref__chart.html#gac7b516d9bbd4ac7926b70e19f74cd5d3", null ],
    [ "I1_REFERENCE_CHART_LAB", "group__ref__chart.html#gadadb56990315117f5947e34c150b4c5c", null ]
];