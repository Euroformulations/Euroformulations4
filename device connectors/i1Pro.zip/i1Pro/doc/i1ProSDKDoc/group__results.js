var group__results =
[
    [ "I1_GetNumberOfAvailableSamples", "group__results.html#ga537a810ba92322bf7ecc655de32a989b", null ],
    [ "I1_GetSpectrum", "group__results.html#ga0f42d7bee9341a5023fc3198b95b4d39", null ],
    [ "I1_GetTriStimulus", "group__results.html#gad0bdf6f73bb4fe04fe1d4bcdcbca1860", null ],
    [ "I1_GetDensities", "group__results.html#ga347818a5db1a056e63146de1298c8bb8", null ],
    [ "I1_GetDensity", "group__results.html#ga5767fe25983beb91da0430032884eef3", null ],
    [ "I1_SetSubstrate", "group__results.html#gab5295137d0fde7d45299d04deeede5da", null ],
    [ "I1_SetReferenceChartLine", "group__results.html#ga678c9d8ce52c14f30db572a268417bd2", null ]
];