var group__measurement__mode__kv =
[
    [ "I1_AVAILABLE_MEASUREMENT_MODES", "group__measurement__mode__kv.html#gad0dd04c2e2cf0f845de1ca60f7659aa5", null ],
    [ "I1_MEASUREMENT_MODE", "group__measurement__mode__kv.html#gab154ea20dec6ba5e721067ee68020402", null ],
    [ "I1_MEASUREMENT_MODE_UNDEFINED", "group__measurement__mode__kv.html#ga1bd26c52512609ee605e020f8aa3f4a9", null ],
    [ "I1_REFLECTANCE_SPOT", "group__measurement__mode__kv.html#ga09049b0ec10181e0756ecf97194ebeca", null ],
    [ "I1_REFLECTANCE_SCAN", "group__measurement__mode__kv.html#ga6f7cdc69c644d0fa88aef473caa7075e", null ],
    [ "I1_EMISSION_SPOT", "group__measurement__mode__kv.html#ga0d2635fe8f424589977760ee88dd6558", null ],
    [ "I1_AMBIENT_LIGHT_SPOT", "group__measurement__mode__kv.html#ga98197a61cf18fb93a4c6c08c2e437c4d", null ],
    [ "I1_AMBIENT_LIGHT_SCAN", "group__measurement__mode__kv.html#ga86cfadb647032ecd2da99958ca4d7544", null ],
    [ "I1_DUAL_REFLECTANCE_SPOT", "group__measurement__mode__kv.html#gaa68f58d1e76abb11245a02008bd5e893", null ],
    [ "I1_DUAL_REFLECTANCE_SCAN", "group__measurement__mode__kv.html#ga18f7748d53b6e04b66f84bac3bb37d72", null ]
];