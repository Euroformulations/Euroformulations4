﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace i1ProTester
{
    class iOneManager
    {

        private byte[] ip;
        private int port;
        private string sExecutablePath;
        private bool bServiceRunning = false;
        private TcpListener serverSocket = null;
        private HandleClinet client2Send = null;   //client che uso per inviare
        private HandleClinet client2Receive = null; //client che uso per ricevere
        private System.Timers.Timer timerController = null;
        private Thread tStart = null;
        Process process = null;

        #region EVENT HANDLER
        public event DeviceDataReceivedEventHandler DataReceived = null;
        public delegate void DeviceDataReceivedEventHandler(string s);

        public event WhiteCalibrationEventHandler WhiteCalibrated = null;
        public delegate void WhiteCalibrationEventHandler();

        public event InitializationEventHandler Initialized = null;
        public delegate void InitializationEventHandler(string s);

        public event ErrorDeviceEventHandler DeviceError = null;
        public delegate void ErrorDeviceEventHandler(string s);
        #endregion

        public iOneManager(int port, string sExecutablePath)
        {
            ip = new byte[] { 127, 0, 0, 1 };
            this.port = port;
            this.sExecutablePath = sExecutablePath;

            if (!System.IO.File.Exists(sExecutablePath))
            {
                if (DeviceError != null) { DeviceError("device client not found"); }
            }
        }

        public bool IsServiceRunning
        {
            get { return bServiceRunning; }
        }

        public void StartService()
        {
            //start server
            if (bServiceRunning) { return; }

            timerController = new System.Timers.Timer(7000);
            timerController.Elapsed += new System.Timers.ElapsedEventHandler(ChannelControllerTick);

            tStart = new Thread(StartExecute);

            //avvio servizio + controllore
            tStart.Start();
            timerController.Start();
        }

        public void StopService()
        {
            if (!bServiceRunning) { return; }

            bServiceRunning = false;

            if (client2Send != null)
            {
                client2Send.SendSTOPRequest();  // ask executable client to terminate
                if (!process.WaitForExit(5000)) //wait 5 seconds, after that it forces to terminate
                {
                    client2Send.CloseClient();
                }
            }

            if (client2Receive != null) { client2Receive.CloseClient(); }

            serverSocket.Stop();
        }

        #region EXTERNAL REQUESTS
        public void CIELabRequest()
        {
            if (client2Send != null)
            {
                client2Send.SendCommand("lab");
            }
        }
        public void WhiteCalibrationRequest()
        {
            if (client2Send != null)
            {
                client2Send.SendCommand("white");
            }
        }
        public void DeviceInitRequest()
        {
            if (client2Send != null)
            {
                client2Send.SendInitialization();
            }
        }
        #endregion

        #region FUNCTIONS
        private void StartExecute()
        {
            try
            {
                serverSocket = new TcpListener(new IPAddress(ip), port);

                //start server
                serverSocket.Start();

                //start executable client
                this.process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        CreateNoWindow = true,
                        UseShellExecute = false,
                        FileName = this.sExecutablePath,
                        WindowStyle = ProcessWindowStyle.Hidden,
                        Arguments = " " + this.port.ToString()
                    }
                };
                process.EnableRaisingEvents = true;
                process.Exited += this.ProcessExited;
                process.Start();

                //receive connection 1
                TcpClient clientSocket = serverSocket.AcceptTcpClient();
                client2Receive = new HandleClinet(clientSocket);
                client2Receive.startClient();

                //receive connection 2
                clientSocket = serverSocket.AcceptTcpClient();
                client2Send = new HandleClinet(clientSocket);
                client2Send.startClient();

                //aspetta finchè i client non sono identificabili
                while (!client2Receive.ThreadInited || !client2Receive.ThreadInited) { Thread.Sleep(1); }

                //se client usato per ricevere dall'altra parte è in ascolto allora devo scambiare i due canali
                if (client2Receive.IsChannelSender_ServerSide)
                {
                    HandleClinet temp = client2Receive;
                    client2Receive = client2Send;
                    client2Send = temp;
                }

                client2Send.DataReceived += new HandleClinet.DataReceivedEventHandler(Ricevuto);
                client2Receive.DataReceived += new HandleClinet.DataReceivedEventHandler(Ricevuto);

                bServiceRunning = true;
            }
            catch (Exception ex)
            {
                try { StopService(); }
                catch (Exception) { }
                throw new Exception(ex.Message);
            }
        }
        private void ChannelControllerTick(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (tStart != null)
            {
                if (tStart.IsAlive)
                {
                    try { StopService(); }
                    catch (Exception) { }
                    if (DeviceError != null) { DeviceError("No exe device connection"); }
                }
            }
            timerController.Stop();
        }
        private void Ricevuto(string data)
        {
            if (data.StartsWith("lab"))
            {
                string[] items = data.Split('\t');
                if (DataReceived != null) { DataReceived(items[1] + "\t" + items[2] + "\t" + items[3]); }
            }
            else if (data == "white_done")
            {
                if (WhiteCalibrated != null) { WhiteCalibrated(); }
            }
            else if (data.StartsWith("statusInit"))
            {
                string[] items = data.Split('\t');
                if (Initialized != null) { Initialized(items[1]); }
            }
            else if (data.StartsWith("err") || data.StartsWith("initerr"))
            {
                string[] items = data.Split('\t');
                if (DeviceError != null) { DeviceError(items[1]); }
            }
        }
        private void ProcessExited(object sender, EventArgs e)
        {
            Process p = (Process)sender;
            if (p.ExitCode != 0)
            {
                //error
                try
                {
                    StopService();
                }
                catch (Exception) { }
                if (DeviceError != null) { DeviceError("exedeverror:" + p.ExitCode.ToString()); }
            }
        }
        #endregion
    }
}