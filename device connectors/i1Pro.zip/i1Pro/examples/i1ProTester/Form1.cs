﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Threading;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Diagnostics;

namespace i1ProTester
{
    public partial class Form1 : Form
    {
        iOneManager manager = null;

        public Form1()
        {
            InitializeComponent();
            btnClose.Enabled = false;
            btnInit.Enabled = false;
            btnLab.Enabled = false;
            btnW.Enabled = false;
        }

        private void RicevutoLAB(string sData)
        {
            Control.CheckForIllegalCrossThreadCalls = false; // importante per EF4
            txtLog.Text = txtLog.Text + Environment.NewLine + sData;
        }

        private void BIANCO() { MessageBox.Show("BIANCO CALIBRATO"); }

        private void INIZIALIZZATO(string data)
        {
            if (data == "")
                MessageBox.Show("Risultato: OK!");
            else
                MessageBox.Show("Risultato: " + data);
        }

        private void ERROR(string error) { MessageBox.Show(error); }

        private void btnLab_Click(object sender, EventArgs e)
        {
            manager.CIELabRequest();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            btnClose_Click(null, null);
        }

        private void btnW_Click(object sender, EventArgs e)
        {
            manager.WhiteCalibrationRequest();
        }

        private void btnInit_Click(object sender, EventArgs e)
        {
            manager.DeviceInitRequest();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtLog.Text = "";
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            manager = new iOneManager(8888, Directory.GetCurrentDirectory() + "\\i1Pro.exe");
            manager.StartService();
            manager.DataReceived += new iOneManager.DeviceDataReceivedEventHandler(RicevutoLAB);
            manager.WhiteCalibrated += new iOneManager.WhiteCalibrationEventHandler(BIANCO);
            manager.Initialized += new iOneManager.InitializationEventHandler(INIZIALIZZATO);
            manager.DeviceError += new iOneManager.ErrorDeviceEventHandler(ERROR);
            btnOpen.Enabled = false;
            btnInit.Enabled = true;
            btnClose.Enabled = true;
            btnLab.Enabled = true;
            btnW.Enabled = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (manager != null)
            {
                if (manager.IsServiceRunning)
                {
                    manager.StopService();
                }
            }
            btnOpen.Enabled = true;
            btnInit.Enabled = false;
            btnClose.Enabled = false;
            btnLab.Enabled = false;
            btnW.Enabled = false;
        }









    }
}
