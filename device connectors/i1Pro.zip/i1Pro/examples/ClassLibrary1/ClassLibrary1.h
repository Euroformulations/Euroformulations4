// ClassLibrary1.h

#pragma once

using namespace System;

namespace ClassLibrary1 {

	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
