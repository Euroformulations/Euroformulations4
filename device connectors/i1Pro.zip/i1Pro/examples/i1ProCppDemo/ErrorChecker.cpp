#include "ErrorChecker.h"
#include <i1Pro.h>
#include <MeasurementConditions.h>
#include <string>

static char sBuffer[256] = {};
static I1_UInteger sBufferLength = 256;

ErrorChecker::ErrorChecker()
{
}

ErrorChecker::ErrorChecker(I1_ResultType result)
{
	if (result != eNoError) {
		// return an english error description
		I1_GetGlobalOption(I1_LAST_ERROR_TEXT, sBuffer, &sBufferLength);
		std::string errorText(sBuffer);

		// the internal error number helps XRite to identify your problem
		I1_GetGlobalOption(I1_LAST_ERROR_NUMBER, sBuffer, &sBufferLength);
		std::string errorNumber(sBuffer);

		throw std::runtime_error(errorText + "\nErrorNumber: " + errorNumber);
	}
}

ErrorChecker::~ErrorChecker()
{
}
