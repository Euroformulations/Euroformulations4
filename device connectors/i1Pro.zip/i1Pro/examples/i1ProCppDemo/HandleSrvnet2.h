#pragma once
#include <ws2tcpip.h>

#include <i1Pro.h>

class HandleSrvnet2
{
public:
	HandleSrvnet2();
	HandleSrvnet2(PCSTR port);
	~HandleSrvnet2();
	bool Connect();

private:
	SOCKET ConnectSocket;
	PCSTR port;
	PCSTR ip = "127.0.0.1";
};

