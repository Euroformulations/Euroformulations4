#include <ws2tcpip.h>
#include<string>

using namespace std;

class HandleSrvnet
{

private:
	SOCKET ConnectSocket;
	PCSTR port;
	PCSTR ip = "127.0.0.1";

public:
	HandleSrvnet(PCSTR port)
	{
		this->port = port;
	}
	bool Connect()
	{
		this->port = port;
		WSADATA wsaData;
		ConnectSocket = INVALID_SOCKET;
		struct addrinfo *result = NULL,
			*ptr = NULL,
			hints;
		char *sendbuf = "this is a test";

		int iBufferLenght = 512;

		char* recvbuf = new char[iBufferLenght];
		int iResult;
		//int recvbuflen = iBufferLenght;

		// Initialize Winsock
		iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
		if (iResult != 0) {
			printf("WSAStartup failed with error: %d\n", iResult);
			return false;
		}

		ZeroMemory(&hints, sizeof(hints));
		hints.ai_family = AF_UNSPEC;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;

		// Resolve the server address and port
		iResult = getaddrinfo(ip, port, &hints, &result);
		if (iResult != 0) {
			printf("getaddrinfo failed with error: %d\n", iResult);
			WSACleanup();
			return false;
		}

		// Attempt to connect to an address until one succeeds
		for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
		{
			// Create a SOCKET for connecting to server
			ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
			if (ConnectSocket == INVALID_SOCKET) {
				printf("socket failed with error: %ld\n", WSAGetLastError());
				WSACleanup();
				return false;
			}

			// Connect to server.
			iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
			if (iResult == SOCKET_ERROR) {
				closesocket(ConnectSocket);
				ConnectSocket = INVALID_SOCKET;
				continue;
			}
			break;
		}

		freeaddrinfo(result);

		if (ConnectSocket == INVALID_SOCKET)
		{
			printf("Unable to connect to server!\n");
			WSACleanup();
			return false;
		}

		return true;
	}

	void Send(string data)
	{
		int nchars = data.size();
		data = to_string(nchars) + ";" + data;
		send(ConnectSocket, data.c_str(), strlen(data.c_str()), 0);
	}

	string Receive()
	{
		int bufSize = 512;
		char* buffer = new char[bufSize];
		recv(ConnectSocket, buffer, bufSize, 0);
		string data = "";
		data.append(buffer, bufSize);
		int pos = data.find(';');
		int nCaratteri = stoi(data.substr(0, pos));
		string messaggio = data.substr(pos + 1, nCaratteri);
		return messaggio;
	}

};