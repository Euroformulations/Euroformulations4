#pragma once
#include "C:\EUROCOLORI\Euroformulations4\Euroformulations4\1 - implementazioni dispositivi\i1Pro\server\i1Pro_SDK_4.2.0\include\i1Pro.h"
#include "C:\EUROCOLORI\Euroformulations4\Euroformulations4\1 - implementazioni dispositivi\i1Pro\server\i1Pro_SDK_4.2.0\include\MeasurementConditions.h"

class ErrorChecker
{
public:
	ErrorChecker();
	ErrorChecker(I1_ResultType result);
	~ErrorChecker();
};

