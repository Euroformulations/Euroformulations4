// IONEWrapper.h

#pragma once
#include<string>
#include "c:\Users\Max\Desktop\i1Pro_SDK_4.2.0\examples\i1ProCppDemo\IONEManager.h"
#include "C:\Users\Max\Desktop\i1Pro_SDK_4.2.0\examples\i1ProCppDemo\IOneManager.cpp"

using namespace System;

namespace IONEWrapper {

	public ref class XRiteWrapper
	{
	public:
		XRiteWrapper();
		

		std::string Calibra2();
		void Connect2();
		void Read2();

	/*private:
		IONEManager* manager;*/

	};
}
