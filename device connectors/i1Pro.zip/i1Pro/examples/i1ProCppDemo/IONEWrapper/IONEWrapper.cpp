// This is the main DLL file.

#include "stdafx.h"

#include "IONEWrapper.h"
#include<string>


//#include "c:\Users\Max\Desktop\i1Pro_SDK_4.2.0\examples\i1ProCppDemo\IONEManager.h"
//#include "C:\Users\Max\Desktop\i1Pro_SDK_4.2.0\examples\i1ProCppDemo\IOneManager.cpp"



IONEWrapper::XRiteWrapper::XRiteWrapper()
{
	//this->manager = new IONEManager();
}




std::string IONEWrapper::XRiteWrapper::Calibra2()
{
	return "";// this->manager->Calibra();
}

void IONEWrapper::XRiteWrapper::Connect2()
{
	//this->manager->Connect();
}

void IONEWrapper::XRiteWrapper::Read2()
{
	//this->manager->Read();
}





