#include <winsock2.h>
#include <iostream>
#include <iterator>
#include <list>
#include <stdexcept>
#include <thread>
#include <string>
#include <vector>
#include <i1Pro.h>
#include <MeasurementConditions.h>
#include <windows.h>
#include<io.h>
#include<stdio.h>
#include<string>
#include "HandleSrvnet.cpp"
#include <mutex>

using namespace std;

HandleSrvnet* conn_send;
string dispositivoPronto = "not initialized";
std::mutex mtx;
string GetError(long error);
bool bListenerClosedWithError = false;
char sBuffer[256] = {};
I1_UInteger sBufferLength = 256;
I1_DeviceHandle dev = NULL;
I1_DeviceHandle *devices = NULL;
int eventCounter = 0;
bool bCalibrato = false;
class ErrorChecker {
	public:
		ErrorChecker() { }
		~ErrorChecker() { }
		
		ErrorChecker(I1_ResultType result) {
			if (result != eNoError) {
				// return an english error description
				I1_GetGlobalOption(I1_LAST_ERROR_TEXT, sBuffer, &sBufferLength);
				std::string errorText(sBuffer);

				// the internal error number helps XRite to identify your problem
				I1_GetGlobalOption(I1_LAST_ERROR_NUMBER, sBuffer, &sBufferLength);
				std::string errorNumber(sBuffer);

				throw std::runtime_error(errorText + "\nErrorNumber: " + errorNumber);
			}
		}
};
ErrorChecker sEC;

enum eProgramExitStatus
{
	STATUS_OK = 0,
	SENDER_CHANNEL_ERROR = 1,
	SENDER_CHANNEL_ACK_ERROR = 2,
	RECEIVER_CHANNEL_ERROR = 3,
	RECEIVER_CHANNEL_ACK_ERROR = 4,
	NO_PORT_SPECIFIED = 5,
	LISTENER_CLOSED_WITH_ERROR = 6
};

void ButtonPressed(I1_DeviceHandle devHndl, I1_DeviceEvent event, void *refCon)
{
	int *eventCounter = static_cast<int*>(refCon);
	*eventCounter += 1;

	if (event != eI1ProButtonPressed) { return; }

	string risp = "";
	mtx.lock();
	try
	{
		sEC = I1_TriggerMeasurement(dev); //Leggo i valori di riflettanza
		float tristimulus[TRISTIMULUS_SIZE] = {};
		sEC = I1_GetTriStimulus(dev, tristimulus, 0); // Li convento in Lab
		risp = "lab\t" + to_string(tristimulus[0]) + "\t" + to_string(tristimulus[1]) + "\t" + to_string(tristimulus[2]);
	}
	catch (const std::exception &e)
	{
		string data = e.what();
		risp = "err\t" + data;
	}
	mtx.unlock();
	try
	{
		conn_send->Send(risp);
	}
	catch (...){}
}

string InitializeDevice()
{
	try
	{
		try
		{
			//chisura connessione con il dispositivo
			if (dev != NULL) {
				I1_CloseDevice(dev);
			}
			I1_SetGlobalOption(I1_RESET, I1_ALL);
		}
		catch (...){}

		dev = NULL;

		I1_UInteger count = 0;
		ErrorChecker sEC = I1_GetDevices(&devices, &count);
		if (count == 0)
		{
			return "initerr\tno device connected";
		}
		if (count > 10) 
		{
			return "initerr\ttoo much devices connected";
		}
		
		int i = 0;
		bool bConnesso = false;

		for (int i = 0; i < 20 && !bConnesso; i++)
		{
			for (int j = 0; (j < count) && (!bConnesso); j++)
			{
				try
				{
					dev = devices[j];
					sEC = I1_OpenDevice(dev);
					bConnesso = true;
				}
				catch (...)
				{
					Sleep(1);
				}
			}

			if (!bConnesso)
			{
				Sleep(100);
			}
		}
		
		sEC = I1_SetOption(dev, I1_MEASUREMENT_MODE, I1_DUAL_REFLECTANCE_SPOT);
		sEC = I1_SetOption(dev, ILLUMINATION_KEY, ILLUMINATION_D65);
		sEC = I1_SetOption(dev, OBSERVER_KEY, OBSERVER_TEN_DEGREE);
		sEC = I1_SetOption(dev, COLOR_SPACE_KEY, COLOR_SPACE_CIELab);
		sEC = I1_SetOption(dev, I1_RESULT_INDEX_KEY, I1_ILLUMINATION_CONDITION_M0);

		I1_RegisterDeviceEventHandler(&ButtonPressed, &eventCounter);

		return "";
	}
	catch (const std::exception& ex)
	{
		string errorData = ex.what();
		return "initerr\t" + errorData;
	}
}

void JobListener(HandleSrvnet* conn)
{
	try
	{
		bool bStop = false;
		string risp;
		while (!bStop)
		{
			risp = "";
			string comm = conn->Receive();
			if (comm == "stop")
			{
				bStop = true;
			}
			else
			{
				mtx.lock();
				try
				{
					if (comm == "lab")
					{
						if (dispositivoPronto != "")
						{
							dispositivoPronto = InitializeDevice();
						}
						if (dispositivoPronto != "")
						{
							//error
							risp = dispositivoPronto;
						}
						else
						{
							sEC = I1_TriggerMeasurement(dev); //Leggo i valori di riflettanza
							float tristimulus[TRISTIMULUS_SIZE] = {};
							sEC = I1_GetTriStimulus(dev, tristimulus, 0); // Li convento in Lab
							risp = "lab\t" + to_string(tristimulus[0]) + "\t" + to_string(tristimulus[1]) + "\t" + to_string(tristimulus[2]);
						}
					}
					else if (comm == "white")
					{
						if (dispositivoPronto != "")
						{
							dispositivoPronto = InitializeDevice();
						}
						if (dispositivoPronto != "")
						{
							//error
							risp = dispositivoPronto;
						}
						else
						{
							sEC = I1_Calibrate(dev);
							bCalibrato = true;
							risp = "white_done";
						}
					}
					else if (comm == "init")
					{
						dispositivoPronto = InitializeDevice();
						risp = "statusInit\t" + dispositivoPronto;
					}
					else
					{
						risp = "err\tunknown command " + comm;
					}
				}
				catch (const std::exception &e)
				{
					string data = e.what();
					risp = "err\t" + data;
				}
				mtx.unlock();

				try
				{
					conn->Send(risp);
				}
				catch (...){}
			}
		}
	}
	catch (...)
	{
		bListenerClosedWithError = true;
	}
}

int main(int argc, const char * argv[])
{
	if (sizeof(argv) < 2) { return NO_PORT_SPECIFIED; }
	PCSTR port = argv[1];
	
	//apro canale di invio
	conn_send = new HandleSrvnet(port);
	if (conn_send->Connect())
	{
		conn_send->Send("s");
		string ack = conn_send->Receive();
		if (ack != "ok") { return SENDER_CHANNEL_ACK_ERROR; }
	}
	else
	{
		return SENDER_CHANNEL_ERROR;
	}

	//apro canale in ricezione
	HandleSrvnet* conn_recv = new HandleSrvnet(port);
	if (conn_recv->Connect())
	{
		conn_recv->Send("r");
		string ack2 = conn_recv->Receive();
		if (ack2 != "ok") { return RECEIVER_CHANNEL_ACK_ERROR; }
	}
	else
	{
		return RECEIVER_CHANNEL_ERROR;
	}
	thread tListener = thread(JobListener, conn_recv);
	
	//inizializzo dispositivo comunicando eventuali errori
	dispositivoPronto = InitializeDevice();

	if (dispositivoPronto != "")
	{
		//error
		conn_send->Send(dispositivoPronto);
	}

	tListener.join();

	//chisura connessione con il dispositivo
	if (dev != NULL) {
		I1_CloseDevice(dev);
	}
	I1_SetGlobalOption(I1_RESET, I1_ALL);

	//return
	if (bListenerClosedWithError)
	{
		return LISTENER_CLOSED_WITH_ERROR;
	}
	else
	{
		return STATUS_OK;
	}
}