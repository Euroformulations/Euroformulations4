#pragma once

#include "C:\EUROCOLORI\Euroformulations4\Euroformulations4\1 - implementazioni dispositivi\i1Pro\server\i1Pro_SDK_4.2.0\include\i1Pro.h"
#include  "C:\EUROCOLORI\Euroformulations4\Euroformulations4\1 - implementazioni dispositivi\i1Pro\server\i1Pro_SDK_4.2.0\include\MeasurementConditions.h"
#include <string>

class IONEManager
{
public:
	IONEManager();
	~IONEManager();

	bool Connect();
	void Execute();
	std::string Calibra();
	std::string Read();
	void Close();

private:
	bool bCalibrato;
	I1_DeviceHandle dev = NULL;
	I1_DeviceHandle *devices = NULL;
	
};

