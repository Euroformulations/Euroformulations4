#include "IONEManager.h"
#include "ErrorChecker.h"
#include<string>
#include<iostream>

#ifndef _TOOLS_H_
#define _TOOLS_H_

IONEManager::IONEManager()
{
	this->bCalibrato = false;
}

bool IONEManager::Connect()
{
	I1_UInteger count = 0;
	ErrorChecker sEC = I1_GetDevices(&devices, &count);
	if (count != 1) {
		throw std::runtime_error("No device connected");
	}

	dev = devices[0];
	sEC = I1_OpenDevice(dev);
	sEC = I1_SetOption(dev, I1_MEASUREMENT_MODE, I1_DUAL_REFLECTANCE_SPOT);
	sEC = I1_SetOption(dev, ILLUMINATION_KEY, ILLUMINATION_D65);
	sEC = I1_SetOption(dev, OBSERVER_KEY, OBSERVER_TEN_DEGREE);
	sEC = I1_SetOption(dev, COLOR_SPACE_KEY, COLOR_SPACE_CIELab);
	sEC = I1_SetOption(dev, I1_RESULT_INDEX_KEY, I1_ILLUMINATION_CONDITION_M0);

	return true;
}

IONEManager::~IONEManager()
{
	delete devices;
}


std::string IONEManager::Calibra()
{
	try
	{
		ErrorChecker sEC = I1_Calibrate(dev);
		this->bCalibrato = true;
		return "";
	}
	catch (const std::exception &e)
	{
		this->bCalibrato = false;
		return e.what();
	}
}


std::string IONEManager::Read()
{
	try
	{
		ErrorChecker sEC = I1_TriggerMeasurement(dev); //Leggo i valori di riflettanza
		float tristimulus[TRISTIMULUS_SIZE] = {};
		
		//sEC = I1_SetOption(dev, COLOR_SPACE_KEY, COLOR_SPACE_CIELab);
		

		sEC = I1_GetTriStimulus(dev, tristimulus, 0); // Li convento in Lab
		std::cout << "  " << tristimulus[0] << ", " << tristimulus[1] << ", " << tristimulus[2] << std::endl;

		return std::to_string(tristimulus[0]) + ";" + std::to_string(tristimulus[1]) + ";" + std::to_string(tristimulus[2]);
	}
	catch (const std::exception &e)
	{
		return e.what();
	}
}

void IONEManager::Execute()
{
	

	I1_UInteger count = 0;
	ErrorChecker sEC = I1_GetDevices(&devices, &count);
	if (count < 1) {
		throw std::runtime_error("No device connected");
	}
	std::cout << "Number of connected devices: " << count << std::endl;

	dev = devices[0];         // Apro la connessione
	sEC = I1_OpenDevice(dev); // 

	sEC = I1_SetOption(dev, I1_MEASUREMENT_MODE, I1_DUAL_REFLECTANCE_SPOT);
	sEC = I1_SetOption(dev, ILLUMINATION_KEY, ILLUMINATION_D65);
	sEC = I1_SetOption(dev, OBSERVER_KEY, OBSERVER_TEN_DEGREE);
	sEC = I1_SetOption(dev, COLOR_SPACE_KEY, COLOR_SPACE_CIELab);

	try
	{
		sEC = I1_Calibrate(dev);
	}
	catch (const std::exception &e)
	{
		std::cout << e.what() << std::endl;
	}

	try
	{
		sEC = I1_TriggerMeasurement(dev); //Leggo i valori di riflettanza
		float tristimulus[TRISTIMULUS_SIZE] = {};
		sEC = I1_SetOption(dev, I1_RESULT_INDEX_KEY, I1_ILLUMINATION_CONDITION_M0);

		sEC = I1_GetTriStimulus(dev, tristimulus, 0); // Li convento in Lab
		std::cout << "  " << tristimulus[0] << ", " << tristimulus[1] << ", " << tristimulus[2] << std::endl;
	}
	catch (const std::exception &e)
	{
		std::cout << e.what() << std::endl;
	}

	std::cout << std::endl;

	if (dev != NULL) {
		// we are finished, close the device
		I1_CloseDevice(dev);
	}
}

void IONEManager::Close()
{
	if (dev != NULL) {
		I1_CloseDevice(dev);
	}
	I1_SetGlobalOption(I1_RESET, I1_ALL);
}


static char sBuffer[256] = {};
static I1_UInteger sBufferLength = 256;

#endif
