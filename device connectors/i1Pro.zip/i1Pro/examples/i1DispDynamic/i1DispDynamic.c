/*******************************************************************************
* Copyright (c) 2005-2012 X-Rite Inc.  All Rights Reserved.
*
* i1DispDynamic.c shows how to dynamically load the older 'EyeOne.dll' or 
* 'i1C.framework' (Version 3.x) to support i1Display 1&2 devices.
*
* THIS FILE CANNOT BE REDISTRIBUTED in source code (or human readable) form.
*
* THIS SOFTWARE IS PROVIDED BY X-RITE ''AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL X-RITE BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/
#include <stdio.h>
#include "EyeOne.h"

#ifdef WIN32
  #include <Windows.h>
#elif __APPLE_CC__   // Mac OS X
  #include <dlfcn.h>
#endif


/* help functions */
int LoadI1Library();
void UnloadI1Library();


/* Global function pointers to all required functions for i1Display */
static FPtr_I1_GetOption           i1_GetOption = NULL;
static FPtr_I1_SetOption           i1_SetOption = NULL;
static FPtr_I1_IsConnected         i1_IsConnected = NULL;
static FPtr_I1_Calibrate           i1_Calibrate = NULL;
static FPtr_I1_TriggerMeasurement  i1_TriggerMeasurement = NULL;
static FPtr_I1_GetTriStimulus      i1_GetTriStimulus = NULL;

/* holds the loaded Library */
#ifdef WIN32
  static HMODULE sI1Library = NULL;
#elif __APPLE_CC__   // Mac OS X
  static void *sI1Library = NULL;
#endif


int main (int argc, const char * argv[])
{
  if (LoadI1Library() == 0) {
    printf("Loading i1 library failed");
    return -1;
  }
  printf("EyeOne SDK version %s\n", i1_GetOption(I1_VERSION));
  /* we are interested in i1Display only, ignore i1Pro */
  i1_SetOption(I1_DEVICE_TYPE, I1_DISPLAY);

  if(i1_IsConnected() == eNoError)
  {
    int userInput = 0;
    float colorVector[TRISTIMULUS_SIZE];

    printf("\n\nDevice Infos:\n");
    printf(" I1_SERIAL_NUMBER:               %s\n", i1_GetOption(I1_SERIAL_NUMBER));
    printf(" I1_DEVICE_TYPE:                 %s\n", i1_GetOption(I1_DEVICE_TYPE));
    fflush(stdout);

    /* set measuremode and apropriate screen type, eg LCD */
    i1_SetOption(I1_MEASUREMENT_MODE, I1_SINGLE_EMISSION);
    i1_SetOption(I1_SCREEN_TYPE, I1_LCD_SCREEN);

    printf("\nCalibrating (device must be on a clean planar surface)...\n"); fflush(stdout);
    i1_Calibrate();

    printf("\nPress any number and hit the ENTER key to measure\n"); fflush(stdout);
    scanf("%d", &userInput);
    printf("taking measurement...\n"); fflush(stdout);
    i1_TriggerMeasurement();

    /* print result as xyY */
    i1_SetOption(COLOR_SPACE_KEY, COLOR_SPACE_CIExyY);
    i1_GetTriStimulus(colorVector, 0);

    printf(" x- Value: %3.3f\n", colorVector[0]);
    printf(" y- Value: %3.3f\n", colorVector[1]);
    printf(" Y- Value: %3.3f\n", colorVector[2]);
    printf(" cd/m2: %3.3f\n", colorVector[2]);

    /* release device */
    i1_SetOption(I1_RESET, I1_ALL);
  } else {
    printf("No device connected\n");
  }

  UnloadI1Library();

  printf("\n\nEnd of demo\n");
  fflush(stdout);
  
  return 0;
}


int LoadI1Library()
{
#ifdef WIN32
  sI1Library            = LoadLibrary(L"EyeOne.dll");
  i1_GetOption          = (FPtr_I1_GetOption)         GetProcAddress(sI1Library, "I1_GetOption");
  i1_SetOption          = (FPtr_I1_SetOption)         GetProcAddress(sI1Library, "I1_SetOption");
  i1_IsConnected        = (FPtr_I1_IsConnected)       GetProcAddress(sI1Library, "I1_IsConnected");
  i1_Calibrate          = (FPtr_I1_Calibrate)         GetProcAddress(sI1Library, "I1_Calibrate");
  i1_TriggerMeasurement = (FPtr_I1_TriggerMeasurement)GetProcAddress(sI1Library, "I1_TriggerMeasurement");
  i1_GetTriStimulus     = (FPtr_I1_GetTriStimulus)    GetProcAddress(sI1Library, "I1_GetTriStimulus");

#elif __APPLE_CC__   // Mac OS X
  sI1Library = dlopen("i1C.framework/i1C", RTLD_LAZY);
  i1_GetOption          = (FPtr_I1_GetOption)         dlsym(sI1Library, "I1_GetOption");
  i1_SetOption          = (FPtr_I1_SetOption)         dlsym(sI1Library, "I1_SetOption");
  i1_IsConnected        = (FPtr_I1_IsConnected)       dlsym(sI1Library, "I1_IsConnected");
  i1_Calibrate          = (FPtr_I1_Calibrate)         dlsym(sI1Library, "I1_Calibrate");
  i1_TriggerMeasurement = (FPtr_I1_TriggerMeasurement)dlsym(sI1Library, "I1_TriggerMeasurement");
  i1_GetTriStimulus     = (FPtr_I1_GetTriStimulus)    dlsym(sI1Library, "I1_GetTriStimulus");

#endif

  /* check the function pointers */
  (i1_GetOption          != NULL && i1_SetOption      != NULL &&
   i1_IsConnected        != NULL && i1_Calibrate      != NULL &&
   i1_TriggerMeasurement != NULL && i1_GetTriStimulus != NULL)
  ? 0: 1;
}


void UnloadI1Library()
{
#ifdef WIN32
  FreeLibrary(sI1Library);
#elif __APPLE_CC__   // Mac OS X
  dlclose(sI1Library);
#endif
  sI1Library            = NULL;
  i1_GetOption          = NULL;
  i1_SetOption          = NULL;
  i1_IsConnected        = NULL;
  i1_Calibrate          = NULL;
  i1_TriggerMeasurement = NULL;
  i1_GetTriStimulus     = NULL;
}

                                                                                                                                                                                                                                                                                                              